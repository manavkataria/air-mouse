#!/usr/bin/python
import struct
import socket
from math import sqrt


x = 0
y = 0
z = 0
secondsensorfile = "/dev/input/event3"


s = socket.socket()
s.bind(("10.0.0.2",7000))
s.listen(1)
(rsock, raddr) = s.accept()

print "Connected..."+str(len(raddr))
#int, int, short, short, int
fmt = 'iihhi'
#open file in binary mode
in_file = open(secondsensorfile,"rb")
event = in_file.read(16)
while event:
	(time1,time2, type, code, value) = \
		struct.unpack(fmt,event)
	time = time2 / 1000.0

	if type == 2 or type == 3:
		if code == 0:
			x = value
		if code == 1:
			y = value
		if code == 2:
			z = value
	if type == 0 and code == 0:
 		sum = int(sqrt(x*x + y*y + z*z))
		print time, x, y, z, sum
		rsock.send( str(x)+','+str(y)+','+str(z)+'\n')
	event = in_file.read(16)
in_file.close()



