#!/usr/bin/python

import socket
from math import sqrt, fabs
from Xlib import X, display


d = display.Display()
s = d.screen()
root = s.root
root.warp_pointer(1280,770)
d.sync()


lsock = socket.socket()
lsock.connect(("10.0.0.2",7000))
lfd = lsock.makefile('r')
print "connected"

xo = 41;
yo = 41;
xCur = 640;
yCur = 380;

while 1 != 0 :
#    acceleration = lsock.recv(100)[1:-1].split(',')
#    print (acceleration[0])+' '+(acceleration[1])+' '+(acceleration[2])
    in_str = lfd.readline()
    v = in_str.split(',')
    x = int(v[0])
    y = int(v[1])
    z = int(v[2])
    xsign = (x)/fabs(x)
    ysign = (y)/fabs(y)
#    sum = int( sqrt(x*x+y*y+z*z))
#    print x-xo, y-yo,
    if fabs(x) > 100:
#        print "__X__",x,
        xCur = xCur -2*xsign;
    if fabs(y) > 90:
#        print "__Y__",y,
        yCur = yCur +1*ysign;
#    print x,y,xCur,yCur,xsign,ysign
    root.warp_pointer(xCur, yCur)
    d.sync()



